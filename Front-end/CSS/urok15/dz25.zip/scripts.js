// Первое задание
var result2 = prompt("Как ваше Фамилия?", "");
var result1 = prompt("Как ваше Имя?", "");
console.log(result2 +" "+ result1);

// Второе задание
var num1 = prompt("Введите первое слагаемое");
var num2 = prompt("Введите второе слагаемое");
alert("Сумма: " + (Number(num1) + Number(num2)));

// Третье задание
var num1 = prompt("Введите первый множитель");
var num2 = prompt("Введите второй множитель");
alert("Произведение: " + (Number(num1) * Number(num2)));