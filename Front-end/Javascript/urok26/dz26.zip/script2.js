var parol = prompt("Введите пароль: ", "");
if(parol === "hello"){
  console.log("Wellcome");
}else{
  console.log("пароль не правильный");
}

var login = prompt("Введите логин: ", "");
if(login === "java"){
  console.log("Wellcome");
}else{
  console.log("логин не правильный");
}