let age = 23;
let year = 1997;
let my_name = "Tinatin";
console.log(age, year, my_name);